# name = input(" Введите ваше имя: ")
# age= int (input("Введите Ваш возраст"))
#
# print(" Привет, "+ name)
# print ("Ого, тебе уже " +str(age) + " лет ")